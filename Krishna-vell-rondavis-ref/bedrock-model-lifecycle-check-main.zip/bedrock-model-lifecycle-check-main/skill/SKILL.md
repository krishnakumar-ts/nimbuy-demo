---
name: model-lifecycle-check
description: Check whether any Bedrock foundation model this project depends on is LEGACY or missing in its configured regions. Use before deploys, when adding or changing a model dependency, when a scheduled lifecycle alert fires, or when diagnosing "model not found" / broken AI-feature errors.
---

# Model Lifecycle Check

A model your app depends on can be deprecated on someone else's schedule. This
skill checks every Bedrock model ID this project uses against the live
lifecycle status in every region the app calls.

## Steps

1. **Find the model IDs.** Grep the project's config for Bedrock model IDs
   (`.env`, `.env.example`, config files, IaC templates). They look like
   `anthropic.claude-*`, `stability.*`, `amazon.nova-*`, optionally prefixed
   with an inference-profile region group (`us.`, `eu.`, `apac.`, `global.`).

2. **Find the regions.** Look for `AWS_REGION` / `AWS_DEFAULT_REGION` values
   and any per-service region overrides. Check every region the app actually
   calls, not just the default.

3. **Run the check** (read-only, free):

   ```bash
   python check_model_lifecycle.py \
       --models <comma-separated-ids> \
       --regions <comma-separated-regions>
   ```

   Or let it scan: `--scan .env --scan config/services.php`.

4. **Interpret the exit code:**
   - `0` — all ACTIVE. Nothing to do.
   - `1` — LEGACY found. A shutdown date exists. Report which models, and
     propose a migration: find an ACTIVE replacement in the same modality
     (`aws bedrock list-foundation-models --region <r> --by-output-modality IMAGE`
     etc.), or an inference profile that routes around the gap.
   - `2` — NOT FOUND in a region the app uses. Treat as an active or imminent
     outage: the feature calling that model in that region is broken. Identify
     an ACTIVE model in that region or another region to route to, and flag
     any hardcoded region assumptions in the client code.

5. **Report** a short table (model × region × status) plus the single
   recommended action. If everything is ACTIVE, say so in one line.

## Notes

- Requires AWS credentials with `bedrock:ListFoundationModels` only.
- Strip inference-profile prefixes when comparing (`us.anthropic.x` → the
  underlying `anthropic.x` is what ListFoundationModels returns); the script
  does this automatically.
- If this repo's weekly CloudFormation alert (template.yaml) fired, run this
  skill to reproduce and scope the impact before proposing fixes.
