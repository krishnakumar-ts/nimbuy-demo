# Is your model on the clock?

One command that tells you whether any foundation model your app depends on has
been marked **LEGACY** — or has quietly disappeared — in the regions you run in.

Read-only. Free to run. No dependencies beyond `boto3`. Exit code is the answer,
so it drops straight into CI.

## Why this exists

One Monday morning my app's image rendering was broken. Not my bug — AWS had
marked the model I used as legacy, and there wasn't a single active
text-to-image model left in us-east-1. I found it by using my own product, not
from a customer ticket. By that night I'd migrated models, region-routed the
clients, and shipped it to production.

The fix took a day. The check that would have warned me weeks earlier takes 30
seconds — Bedrock publishes every model's lifecycle status in a free API call.

**If your product depends on a foundation model, its deprecation calendar is
your uptime calendar.** This repo makes that calendar impossible to ignore.

## Quick start

```bash
pip install boto3

# Check the models you know you use
python check_model_lifecycle.py \
    --models stability.sd3-5-large-v1:0,amazon.nova-canvas-v1:0 \
    --regions us-east-1,us-west-2

# Or scan your config for model IDs automatically
python check_model_lifecycle.py --scan .env --regions us-east-1
```

Output:

```
MODEL                        REGION       STATUS
stability.sd3-5-large-v1:0   us-east-1    NOT FOUND  <-- action needed
stability.sd3-5-large-v1:0   us-west-2    ACTIVE
```

Exit codes: `0` all active · `1` legacy found (a shutdown date exists — start
migrating) · `2` not found (this is how outages start).

The only AWS permission it needs is `bedrock:ListFoundationModels` — read-only,
no cost.

## Use it as a CI gate

A legacy model should fail your build the same way a failing test does. See
[`examples/github-actions.yml`](examples/github-actions.yml):

```yaml
- name: Model lifecycle gate
  run: |
    pip install boto3
    python check_model_lifecycle.py --scan .env.example --regions us-east-1,us-west-2
```

## Optional: weekly check with email alerts

If you'd rather be told than remember to look, [`template.yaml`](template.yaml)
deploys a weekly scheduled check (EventBridge → Lambda → SNS email):

```bash
aws cloudformation deploy \
  --template-file template.yaml \
  --stack-name model-lifecycle-check \
  --capabilities CAPABILITY_IAM \
  --parameter-overrides \
    "ModelIds=stability.sd3-5-large-v1:0,amazon.nova-canvas-v1:0" \
    "Regions=us-east-1,us-west-2" \
    "AlertEmail=you@example.com"
```

**What it costs** (you should always know before you deploy someone's YAML):
EventBridge rules are free, ~4–5 short Lambda runs a month sit inside the
permanent free tier, SNS email is free at this volume, and the logs are a few
KB. Realistic total: **$0.00/month** — worst case without any free tier,
pennies. The full breakdown is in the template's header comment.

## Using Claude Code?

The [`skill/`](skill/) folder wraps this check as a Claude Code skill — drop it
into your project's `.claude/skills/` and Claude will run the lifecycle check
before deploys and when diagnosing "model not found" errors.

## This is Check #1 of 10

Model lifecycle is the first thing I look at in a pre-launch readiness
assessment, because it's the one that fails silently on someone else's
schedule. The other nine:

2. **Quota headroom** — your peak load vs. your actual service quotas, not the defaults you assume you have
3. **Cross-region failover** — can your client route to a second region today, or is that a TODO comment?
4. **Worst-case cost per request** — do you know the number, and is there a ceiling?
5. **Version pinning** — model IDs and prompts pinned and reproducible, or floating on "latest"?
6. **Graceful degradation** — what does a paying customer actually see when the model call fails?
7. **Output validation** — does anything check the model's output before it reaches a customer or a database?
8. **Data handling posture** — what leaves your account inside a prompt, and where does it get logged?
9. **Vendor concentration** — how many features go dark if one provider has a bad day?
10. **Deprecation runbook** — when the notice lands, who migrates what, in what order?

I run these as a working session, not a slide deck. If you want the full
assessment on your product: **[book a slot](https://scheduler.zoom.us/itsrondavis)**.

I also write up what I learn shipping an AI product solo —
[Ron Davis on LinkedIn](https://www.linkedin.com/in/itsrondavis).

## License

[MIT](LICENSE). Use it, fork it, ship it.
