#!/usr/bin/env python3
"""
check_model_lifecycle.py

Answers one question: is any foundation model your app depends on marked
LEGACY -- or missing entirely -- in the regions you run in?

Read-only. One free API call per region (bedrock:ListFoundationModels).
No dependencies beyond boto3. Designed to run in CI: exit code is the answer.

Usage:
  # Check specific model IDs
  python check_model_lifecycle.py \
      --models stability.sd3-5-large-v1:0,amazon.nova-canvas-v1:0 \
      --regions us-east-1,us-west-2

  # Scan a config file (.env, settings, YAML -- any text) for model IDs
  python check_model_lifecycle.py --scan .env --scan config/services.php \
      --regions us-east-1

  # Machine-readable output
  python check_model_lifecycle.py --models ... --regions ... --json

Exit codes:
  0  every model ACTIVE in every region checked
  1  at least one model LEGACY (it has a shutdown date -- start migrating)
  2  at least one model NOT FOUND in a checked region (this is how outages start)
  3  usage or credential error
"""

import argparse
import json
import re
import sys

try:
    import boto3
    from botocore.exceptions import BotoCoreError, ClientError, NoCredentialsError
except ImportError:
    sys.exit("boto3 is required: pip install boto3")

# Bedrock model IDs look like: anthropic.claude-sonnet-4-5-20250929-v1:0,
# stability.sd3-5-large-v1:0, amazon.nova-canvas-v1:0.
# Cross-region inference profiles prefix a region group: us. / eu. / apac. / global.
MODEL_ID_RE = re.compile(
    r"\b(?:(?:us|eu|apac|global)\.)?"
    r"(?:amazon|anthropic|stability|meta|mistral|cohere|ai21|luma|twelvelabs|writer|deepseek)"
    r"\.[A-Za-z0-9][A-Za-z0-9._-]*(?::\d+(?::\d+[km]?)?)?\b"
)

PROFILE_PREFIX_RE = re.compile(r"^(?:us|eu|apac|global)\.")


def strip_profile_prefix(model_id: str) -> str:
    """us.anthropic.foo -> anthropic.foo (ListFoundationModels has no profile entries)."""
    return PROFILE_PREFIX_RE.sub("", model_id)


def scan_files_for_models(paths):
    found = set()
    for path in paths:
        try:
            with open(path, "r", encoding="utf-8", errors="ignore") as fh:
                found.update(MODEL_ID_RE.findall(fh.read()))
        except OSError as exc:
            sys.exit(f"error: cannot read {path}: {exc}")
    return sorted(found)


def fetch_lifecycle(region):
    """Return {modelId: lifecycleStatus} for one region."""
    client = boto3.client("bedrock", region_name=region)
    summaries = client.list_foundation_models()["modelSummaries"]
    return {
        s["modelId"]: s.get("modelLifecycle", {}).get("status", "UNKNOWN")
        for s in summaries
    }


def main():
    parser = argparse.ArgumentParser(
        description="Check Bedrock model lifecycle status for the models your app uses."
    )
    parser.add_argument("--models", default="",
                        help="comma-separated Bedrock model IDs")
    parser.add_argument("--scan", action="append", default=[], metavar="FILE",
                        help="scan a file (.env, config, YAML) for model IDs; repeatable")
    parser.add_argument("--regions", default="",
                        help="comma-separated regions (default: your current AWS region)")
    parser.add_argument("--json", action="store_true", dest="as_json",
                        help="emit JSON instead of a table")
    args = parser.parse_args()

    models = [m.strip() for m in args.models.split(",") if m.strip()]
    if args.scan:
        models = sorted(set(models) | set(scan_files_for_models(args.scan)))
    if not models:
        sys.exit("error: no model IDs given (use --models or --scan)")

    regions = [r.strip() for r in args.regions.split(",") if r.strip()]
    if not regions:
        session_region = boto3.session.Session().region_name
        if not session_region:
            sys.exit("error: no --regions given and no default AWS region configured")
        regions = [session_region]

    rows = []
    worst = 0
    for region in regions:
        try:
            lifecycle = fetch_lifecycle(region)
        except NoCredentialsError:
            sys.exit("error: no AWS credentials found (aws configure / AWS_PROFILE)")
        except (BotoCoreError, ClientError) as exc:
            sys.exit(f"error: ListFoundationModels failed in {region}: {exc}")

        for model in models:
            status = lifecycle.get(strip_profile_prefix(model), "NOT FOUND")
            rows.append({"model": model, "region": region, "status": status})
            if status == "NOT FOUND":
                worst = max(worst, 2)
            elif status != "ACTIVE":
                worst = max(worst, 1)

    if args.as_json:
        print(json.dumps({"results": rows, "exit_code": worst}, indent=2))
    else:
        width = max(len(r["model"]) for r in rows) + 2
        print(f"{'MODEL':<{width}}{'REGION':<15}STATUS")
        for r in rows:
            marker = "" if r["status"] == "ACTIVE" else "  <-- action needed"
            print(f"{r['model']:<{width}}{r['region']:<15}{r['status']}{marker}")
        print()
        if worst == 0:
            print(f"OK: all {len(models)} model(s) ACTIVE in {len(regions)} region(s).")
        elif worst == 1:
            print("WARNING: LEGACY model(s) found. Legacy means a shutdown date "
                  "exists -- migrate before it becomes an outage.")
        else:
            print("FAILURE: model(s) NOT FOUND in a region you depend on. "
                  "If your app calls them there, that feature is already down "
                  "or about to be.")

    sys.exit(worst)


if __name__ == "__main__":
    main()
