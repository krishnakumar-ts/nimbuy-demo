# GTM Skill Pack — MCP Server Scope (Foundry "tools" tier)

**Status (2026-09-11):** the gateway at `mcp.vell.ai` is **not currently serving** — nothing on this page is live for buyers yet. The free sample tier is **built** → [github.com/vell-io/vellocity-mcp](https://github.com/vell-io/vellocity-mcp). This doc scopes the full tiered plan.
**It's not a standalone tool — it's the free `gtm_*` sample tier of the one [Vellocity MCP](https://github.com/vell-io/vellocity-mcp)** (gateway: **`mcp.vell.ai`**), with authenticated (live-data) and metered tiers gated above it. See that repo's `docs/ARCHITECTURE.md` for tiers, repo strategy, and the security model.
**Why:** the free tier ships the *knowledge* (the ten skills as markdown). The paid tier ships the *capability* — the same skills as **live tools** your model runs, via one remote MCP connector URL. Charge for capability/access, not static content. That is the agentic-commerce thesis, dog-fooded.

**Where it leads — the real value is [Vellocity](https://vell.ai).** This MCP is a *teaser of the engine*: the same tools, but thin and scoped. The full motion — listing optimization, co-sell, pricing, demand-gen run continuously against live Marketplace data with an agent layer — is the Vellocity app. Architecturally the cleanest build is to make this MCP a thin public surface over **Vellocity's own in-app MCP/agent layer** (see [[project_agentic_testing_harness]] — "AgentCore = in-app MCP layer"), so the teaser literally calls a scoped slice of the product. Free skills → Foundry tools → Vellocity platform.

---

## 1. What it is

A remote **MCP server** (Streamable HTTP transport) that exposes the GTM skills as callable tools. A buyer adds one URL as a connector in Claude, ChatGPT, or Copilot Studio and the tools appear — no copy-paste, no Project setup. Lowest friction, highest value.

## 2. Tools (v1 — start with three)

| Tool | Input (JSON) | Output |
|---|---|---|
| `listing_audit` | product, ICP, current title/short/long, pricing model, competitors | scorecard (5 dims) + rewritten title/short/long + keyword list + fix-first punch list |
| `cosell_draft` | product, customer/opp, recipient, stage, the ask | subject + ≤120-word message + ACE summary block + 5-day follow-up |
| `pricing_story` | what you sell, current pricing, buyer/budget owner, metering basis, deal goals | value metric + 3-tier package table + pricing narrative + agent-buyer note + private-offer rec |

Each tool's `description` + JSON schema mirrors the matching `SKILL.md` so behavior is identical to the free skill — the difference is it *runs* instead of instructing. Add `agent_ready_audit`, `demandgen_kit`, `discovery_prep` in v2.

## 3. Thin vs. thick — pick the execution model

- **Thin (prompt server):** the tool assembles the expert prompt + the caller's inputs and returns it; the *calling* model does the reasoning. Zero inference cost, no model key, trivially cheap to host. Good free-but-gated tier.
- **Thick (inference server):** the server runs the skill against Bedrock/Claude and returns the finished artifact. Costs inference → **this is what justifies metering/payment** and guarantees consistent output regardless of the caller's model.

**Recommendation:** ship **thick** for the paid tier (it's the product), keep a **thin** fallback for a free "preview" call (e.g., 3 calls/day) so people feel it before paying.

## 4. Auth + gating

- Bearer token on the MCP endpoint; one key per Foundry member (issue on offer purchase, revoke on churn).
- Mirror the existing hardened pattern (QBO + Kajabi MCP are auth-enforced; verify from localhost not external; pm2 delete+start to reload env — see [[reference_kajabi_itsrondavis_embed]] / the QBO MCP exposure notes).
- Free preview tier = unauthenticated but rate-limited + watermarked output ("upgrade for the full run").

## 5. Metering / payment (Ron's rails)

- **v1:** flat Foundry/Vellocity membership unlocks the key (simplest; no per-call accounting).
- **v2 — two rails:** (a) **fiat** Stripe metered / Marketplace contract for human/account buyers; (b) **x402** for agent buyers — *we are the seller*: our metered tools return HTTP 402 + verify a stablecoin (USDC/Base) payment proof. This is the open Coinbase x402 standard (live today on x402scan/agentic.market — no preview dependency). **AgentCore Payments is the buyer side** (PREVIEW, announced 2026-05-07, Coinbase+Stripe): it lets an agent auto-negotiate x402, authenticate a wallet, settle, and get proof, with session spend-limits. List our MCP in the **Coinbase x402 Bazaar** (10,000+ endpoints, via AgentCore Gateway) so agents discover + pay for it — the literal "get bought by an agent" dog-food. Ties to [[project_billing_rails_2026_05]] + [[reference_agentic_market_x402_buyer]].

## 6. Hosting

- **`mcp.vell.ai` is the canonical public Vellocity MCP gateway** (not a per-tool subdomain). Move the existing internal MCPs (QBO, Kajabi) to `internal-mcp.vell.ai` so the public product surface is clean. Cert via DNS-01/Route53 (the working pattern; avoids the :80 LE lock-out per the mcp.vell.ai renewal fix).
- Streamable HTTP (remote MCP) so Claude/ChatGPT connectors accept it directly; `mcp-remote` stdio bridge only if a client needs it.
- **List the Tier-0 sample in AWS Marketplace AI Agents & Tools** + MCP directories — practicing "get found" for the tool itself, and a partner-facing reference example.

## 7. Build plan

1. ~~**Scaffold** the MCP server (TypeScript SDK), 3 tools, thin mode.~~ **DONE** → [vell-io/vellocity-mcp](https://github.com/vell-io/vellocity-mcp) (`gtm_*` sample tier, bearer auth, Streamable HTTP, builds + smoke green).
2. **Wire thick mode** to Bedrock (Claude) behind a flag; structured outputs per tool.
3. **Auth**: per-tenant key + Foundry/Vellocity-purchase issuance; rate-limited free preview.
4. **Host** at `mcp.vell.ai` (DNS-01 cert); smoke-test from a real connector in Claude + ChatGPT.
5. **Meter** (v2): Stripe metered → then x402 / AgentCore Pay for agent-paid calls.
6. **Wire into the funnel**: add the connector URL to the on-site builder's Claude/ChatGPT output and to the Foundry unlock; the README's tier-3 row goes live.

## 8. Open decisions for Ron

- Subdomain: `gtm-mcp.vell.ai` vs `mcp.itsrondavis.com` (brand under the personal hub?).
- Free-preview generosity (calls/day) before the paywall.
- v1 flat Foundry unlock vs. jump straight to metered.
- Which 3 tools first (recommend listing_audit + cosell_draft + pricing_story — highest intent, most demo-able on a call).

---
© 2026 Ron Davis · From listed to bought.
